===============Fun Scarey Prank==============
Step 1: Open "FixIt.vbs"
=============================================
You can modify a shortcut to open it if you want to. ex.(Google Chrome Shortcut remapped to the file" or map a key on the keyboard to it.
Thats it.

I hope you enjoy this prank!